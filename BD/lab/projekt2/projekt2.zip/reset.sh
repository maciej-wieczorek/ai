source ./kafka_reset.sh
source ./db_reset.sh
