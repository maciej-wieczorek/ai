export PROCESSING_MODE="update" # "update/complete"
export ANOMALIES_WINDOW_SIZE="7" # in days
export ANOMALIES_THRESHOLD="40" # in percentage
