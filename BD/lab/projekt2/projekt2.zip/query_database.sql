\c :db_name
select * from :db_table;
