source ./kafka_checkpoints_reset.sh
source ./kafka_topics_reset.sh
