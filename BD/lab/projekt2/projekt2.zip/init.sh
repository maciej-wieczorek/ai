source ./get_data.sh
source ./prepare_db.sh
source ./kafka_reset.sh
source ./build_jars.sh

echo "Init Finished"
